class User:
    def __init__(self, user_id, username, password, tasks):
        self.user_id = user_id
        self.username = username
        self.password = password
        self.tasks = tasks
        
        